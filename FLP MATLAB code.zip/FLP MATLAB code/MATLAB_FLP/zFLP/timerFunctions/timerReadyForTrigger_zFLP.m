function status=timerReadyForTrigger_zFLP
status = 1;