function timerForcedAbort_zFLP
% forced abort is handled just like regular abort
timerAbort_zFLP;
    
