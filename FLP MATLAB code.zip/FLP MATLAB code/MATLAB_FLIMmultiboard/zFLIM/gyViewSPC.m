function gyViewSPC
% start up SPC viewing program
spc_drawInit;