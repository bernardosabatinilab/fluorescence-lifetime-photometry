function chan=spc_mainChannelChoice
global gui
chan=get(gui.spc.spc_main.mainChanChoice,'Value');
