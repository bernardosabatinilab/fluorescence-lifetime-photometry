function status=timerReadyForTrigger_zFLIM
status = 1;