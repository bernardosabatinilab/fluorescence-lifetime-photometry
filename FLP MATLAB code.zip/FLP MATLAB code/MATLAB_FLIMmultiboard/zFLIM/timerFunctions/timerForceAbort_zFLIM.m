function timerForceAbort_zFLIM
% forced abort is handled just like regular abort
timerAbort_zFLIM;
    
