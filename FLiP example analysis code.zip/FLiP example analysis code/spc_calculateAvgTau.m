function avgTau = spc_calculateAvgTau(ch)
%% calculating approximated avg tau using the weighted sum of arrival time

%spc is a data structure that saves all the lifetime histogram information
%of the current acquisition bin (single acquisition)
%spc.lifetimes: array of lifetime histogram
%spc.fits: double exponential fit information
%spc.datainfo: information regarding data acquistion

%ch is a channel number for spc board signal channel

global spc
to = spc.fits{ch}.beta5+spc.fits{ch}.fitstart; %calculating offset time to (can acquire this from fitting a double exponential curve to the histogram)

nsPerPoint=spc.datainfo.psPerUnit/1000; %converting histogram timebin into nano seconds
range = round([spc.fits{ch}.fitstart spc.fits{ch}.fitend]/nsPerPoint);
range(1) = round(to/nsPerPoint);

lifetimes=spc.lifetimes{ch}(range(1):range(2)); %defining the time window of the histogram for analysis

%baseline subtraction
baseline=cal_baseline(ch); %update baseline photon count
lifetimes=lifetimes-baseline;

%calculating population average time of photon arrival
sum1=0;
for j=1:length(lifetimes)
    if(lifetimes(j)>0)
        sum1 = sum1 + ((range(1)-1+j)*spc.datainfo.psPerUnit/1000)*lifetimes(j);
    end
end
sum2=sum(lifetimes);

if(sum2>0)
    avgTau = sum1/sum2- to;
else
    avgTau =0;
end

end